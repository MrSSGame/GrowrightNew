/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.growright.databaseInter;

import com.growright.pojo.Plant;
/**
 *
 * @author Test
 */
public interface PlantDatabaseInter {
  
    Plant getPlant(int plant_id);
}
